import Login from './Login';

// Signup uses the same component as Login (OTP-based)
export default Login;
